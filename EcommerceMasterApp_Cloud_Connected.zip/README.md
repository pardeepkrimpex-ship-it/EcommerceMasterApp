# Ecommerce Master App — Connected Cloud Version

Supabase project URL and Publishable key have been configured in MainActivity.kt.

Database setup:
1. In the Supabase SQL Editor, run SUPABASE_SETUP.sql.
2. Build the Android app.
3. On both phones, install the app.
4. Create one account and use the same account on both phones.
5. Orders/returns are stored in the shared Supabase database.

Security:
- The app contains only the Supabase Publishable key.
- Never put a Supabase secret/service_role key in the Android app.

Important:
- If Supabase email confirmation is enabled, confirm the signup email before first login.
- The app uses Row Level Security so each logged-in account can access only its own records.
